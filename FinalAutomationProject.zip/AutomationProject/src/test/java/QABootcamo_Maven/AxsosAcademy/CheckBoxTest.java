package QABootcamo_Maven.AxsosAcademy;

import base.BaseTest;
import org.testng.annotations.Test;

public class CheckBoxTest extends BaseTest {
 
	CheckBoxPage checkBox;
 
    @Test

    public void verifySelectHomeCheckbox() throws InterruptedException {

        checkBox = new CheckBoxPage(driver);
        checkBox.navigateToCheckbox();
        Thread.sleep(5000);
        checkBox.clickExpandAll();
        Thread.sleep(5000);
        driver.close();
 
     

    }
 
   

}

 